exports.parse = function() {
  return 5;
}
